package constant;

public class Constant {
	public final static String historyDelimeter = "/"; 
	
	
}
